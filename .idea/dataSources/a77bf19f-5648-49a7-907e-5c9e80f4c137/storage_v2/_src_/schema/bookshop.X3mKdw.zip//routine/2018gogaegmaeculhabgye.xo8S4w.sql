CREATE PROCEDURE `2018고객매출합계`(IN 기준금액 DECIMAL(19, 4))
  BEGIN
 SELECT 고객.이름 AS 고객이름, SUM(판매단가 * 수량) AS 판매금액
  FROM 판매내역
    INNER JOIN 판매주문 ON 판매내역.주문연번 = 판매주문.판매연번
    INNER JOIN 고객 ON 판매주문.고객아이디 = 고객.아이디
  WHERE 주문일자 >= '2018-01-01' AND 주문일자 <=  '2018-12-31'
  GROUP BY 고객아이디
  HAVING SUM(판매단가 * 수량) > 기준금액
  ORDER BY 판매금액 DESC;
END;

